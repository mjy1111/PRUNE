from ..trainer import MEND
from ..trainer import SERAC


ALG_TRAIN_DICT = {
    'MEND': MEND,
    'SERAC': SERAC
}